import { n as __toESM } from "../_runtime.mjs";
import { t as collections } from "./collections-vvy82Ul_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-DurlFYMP.mjs";
import { t as useHoverPreview } from "./hover-preview-CQuwEoW5.mjs";
import { a as Menu, c as ArrowUpRight, i as Phone, o as Mail, t as X, u as ArrowDown } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes--kyVBd_B.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var nil_hero_default = "/assets/nil-hero-DVXsMWlB.jpg";
var reviews = [
	{
		name: "Elif Arslan",
		city: "İstanbul",
		text: "Salonumuzun tamamını Nil Mobilya ile yeniledik. Oranlar ve kumaş dokusu beklediğimizin çok üzerinde çıktı."
	},
	{
		name: "Mert Şahin",
		city: "Ankara",
		text: "Ceviz yemek masası tam ölçüsünde üretildi. İşçilik detayları gerçekten el yapımı hissi veriyor."
	},
	{
		name: "Selin Yıldırım",
		city: "İzmir",
		text: "Okuma köşesi berjerimi iki yıldır kullanıyorum, formu ilk günkü gibi duruyor."
	},
	{
		name: "Kaan Demir",
		city: "Bursa",
		text: "Ofisimiz için adetli üretim yaptılar. Teslim süresi ve renk tutarlılığı kusursuzdu."
	},
	{
		name: "Duygu Çetin",
		city: "İstanbul",
		text: "Modüler köşe takımı dar bir alanı ferah gösterdi. Tasarım ekibinin yönlendirmesi çok değerliydi."
	},
	{
		name: "Ahmet Korkmaz",
		city: "Antalya",
		text: "Kadife döşemenin tonu evdeki ışıkla birebir uyumlu geldi. Sessiz ama güçlü bir duruşu var."
	}
];
function ReviewCard({ review }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "w-[300px] shrink-0 border border-border bg-surface-raised/75 p-7 backdrop-blur-sm transition-colors hover:border-primary/50 md:w-[380px]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-display text-4xl leading-none text-primary/50",
				children: "“"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "mt-3 select-none text-sm font-light leading-7 text-ink-soft",
				children: review.text
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
				className: "mt-6 flex items-center justify-between border-t border-border pt-4 text-[10px] uppercase tracking-[0.18em]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-foreground/85",
					children: review.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted-foreground",
					children: review.city
				})]
			})
		]
	});
}
function ReviewsMarquee() {
	const trackRef = (0, import_react.useRef)(null);
	const offset = (0, import_react.useRef)(0);
	const velocity = (0, import_react.useRef)(0);
	const dragging = (0, import_react.useRef)(false);
	const loopWidth = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		const track = trackRef.current;
		if (!track) return;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		let frame = 0;
		const measure = () => {
			loopWidth.current = track.scrollWidth / 2;
		};
		measure();
		const observer = new ResizeObserver(measure);
		observer.observe(track);
		const tick = () => {
			const width = loopWidth.current || 1;
			if (!dragging.current) {
				offset.current -= velocity.current;
				velocity.current *= .94;
				if (Math.abs(velocity.current) < .05) {
					velocity.current = 0;
					if (!reduced) offset.current -= .35;
				}
			}
			if (offset.current <= -width) offset.current += width;
			if (offset.current > 0) offset.current -= width;
			track.style.transform = `translate3d(${offset.current}px, 0, 0)`;
			frame = requestAnimationFrame(tick);
		};
		frame = requestAnimationFrame(tick);
		return () => {
			cancelAnimationFrame(frame);
			observer.disconnect();
		};
	}, []);
	const lastX = (0, import_react.useRef)(0);
	const onPointerEnter = (event) => {
		lastX.current = event.clientX;
	};
	const onPointerDown = (event) => {
		dragging.current = true;
		velocity.current = 0;
		lastX.current = event.clientX;
		event.currentTarget.setPointerCapture(event.pointerId);
	};
	const onPointerMove = (event) => {
		const delta = event.clientX - lastX.current;
		lastX.current = event.clientX;
		if (dragging.current) {
			offset.current += delta;
			velocity.current = -delta;
		} else if (event.pointerType !== "touch") {
			velocity.current += -delta * .045;
			velocity.current = Math.max(-10, Math.min(10, velocity.current));
		}
	};
	const endDrag = (event) => {
		if (!dragging.current) return;
		dragging.current = false;
		if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
	};
	const loop = [...reviews, ...reviews];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "yorumlar",
		"aria-label": "Müşteri yorumları",
		className: "border-y border-border bg-muted/30 py-16 md:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-10 flex items-end justify-between px-5 md:px-12 lg:px-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-primary",
				children: "Yaşayanlar anlatıyor"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl md:text-6xl",
				children: "Müşteri Yorumları"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden text-xs text-muted-foreground md:block",
				children: "Sürükleyin · örnek yorumlar"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative cursor-grab touch-pan-y overflow-hidden active:cursor-grabbing [mask-image:linear-gradient(90deg,transparent,#000_8%,#000_92%,transparent)]",
			onPointerDown,
			onPointerEnter,
			onPointerMove,
			onPointerUp: endDrag,
			onPointerCancel: endDrag,
			onPointerLeave: endDrag,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: trackRef,
				className: "flex w-max gap-6 px-6 will-change-transform",
				children: loop.map((review, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewCard, { review }, `${review.name}-${index}`))
			})
		})]
	});
}
var materials = [
	{
		name: "Carrara Mermeri",
		origin: "Toskana, İtalya",
		image: "/assets/material-mermer-CoBcAWMW.jpg",
		why: "Yoğun kristal yapısı sayesinde ince damarlı, soğuk ve berrak bir yüzey verir; sehpa ve konsol tablalarında yıllar içinde çizilse bile karakterini kaybetmez.",
		source: "Apuan Alpleri ocaklarından blok halinde alınır, İstanbul atölyemizde kesilip elde mat cilalanır."
	},
	{
		name: "Masif Ceviz",
		origin: "Kuzey Amerika",
		image: "/assets/material-ceviz-BIRs5vjs.jpg",
		why: "Sert ama işlenebilir yapısı, derin kahve tonu ve canlı damar deseniyle masalarda hem dayanıklılık hem de doğal bir sıcaklık sağlar.",
		source: "FSC sertifikalı ormanlardan gelen kereste, 18 ay doğal kurutma sonrası doğal yağ ile bitirilir."
	},
	{
		name: "Yün Bouclé",
		origin: "Belçika",
		image: "/assets/material-boucle-BRxvoS42.jpg",
		why: "İlmekli dokusu ışığı yumuşatır, oturma gruplarına hacim kazandırır; yün içeriği nefes aldığı için uzun oturmalarda konfor kaybolmaz.",
		source: "Belçikalı bir aile dokuma fabrikasından, 60.000 Martindale aşınma testli toplarla temin edilir."
	},
	{
		name: "Pamuk Kadife",
		origin: "Bursa, Türkiye",
		image: "/assets/material-kadife-DTEuTV9U.jpg",
		why: "Kısa ve yoğun hav, rengi derinleştirir; berjer gibi heykelsi formlarda kavisleri kırışmadan sarar.",
		source: "Bursa'nın köklü kadife dokumacılarıyla çalışıyoruz; renkler bizim paletimize göre parti parti boyanır."
	},
	{
		name: "Tam Tabaka Deri",
		origin: "Toskana, İtalya",
		image: "/assets/material-deri-kQzExQNq.jpg",
		why: "Yüzeyi inceltilmediği için kullandıkça patine olur, yırtılmaya karşı en dayanıklı deri sınıfıdır.",
		source: "Bitkisel tabaklama yapan Toskana tabakhanelerinden, krom içermeyen tabaka halinde alınır."
	},
	{
		name: "Dövme Pirinç",
		origin: "İstanbul, Türkiye",
		image: "/assets/material-pirinc-7jvuJ_qE.jpg",
		why: "Sıcak sarı tonu ceviz ve kadifeyle dengelenir; zamanla oksitlenip yumuşayan yüzeyi altın vurgularımızın kaynağıdır.",
		source: "Ayak, kulp ve bağlantı detayları yerel bir döküm atölyesinde üretilip elde fırçalanır."
	}
];
function MaterialsSection() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "malzeme",
		"aria-label": "Malzeme ve doku",
		className: "border-t border-border px-5 pb-20 md:px-12 lg:px-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-10 flex items-end justify-between border-b border-border pb-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-primary",
				children: "Malzeme künyesi"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-4xl md:text-6xl",
				children: "Malzeme ve Doku"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden max-w-xs text-xs leading-5 text-muted-foreground md:block",
				children: "Her parçanın arkasındaki hammadde, neden seçildiği ve nereden geldiği."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-x-8 gap-y-14 md:grid-cols-2 lg:grid-cols-3",
			children: materials.map((material) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "group",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden bg-surface-raised",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: material.image,
							alt: `${material.name} dokusu yakın çekim`,
							width: 1280,
							height: 960,
							loading: "lazy",
							className: "aspect-[4/3] w-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(.2,.75,.2,1)] group-hover:scale-[1.05]"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex items-baseline justify-between gap-4 border-b border-border pb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl md:text-3xl",
							children: material.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase tracking-[0.18em] text-primary",
							children: material.origin
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm font-light leading-7 text-ink-soft",
						children: material.why
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs leading-6 text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary/80",
							children: "Temin: "
						}), material.source]
					})
				]
			}, material.name))
		})]
	});
}
var INTRO_DURATION = 5600;
function IntroSequence() {
	const [visible, setVisible] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => setVisible(false), INTRO_DURATION);
		return () => window.clearTimeout(timer);
	}, []);
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "intro-screen",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "intro-marble" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "intro-brand",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "intro-title",
				children: "Nil Mobilya"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "intro-tagline",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "modern" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: "·" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "rahat" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { children: "·" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "kişisel" })
				]
			})]
		})]
	});
}
function Index() {
	const [menuOpen, setMenuOpen] = (0, import_react.useState)(false);
	const preview = useHoverPreview();
	const handleDepth = (event) => {
		if (event.pointerType === "touch") return;
		const bounds = event.currentTarget.getBoundingClientRect();
		const x = ((event.clientX - bounds.left) / bounds.width - .5) * -14;
		const y = ((event.clientY - bounds.top) / bounds.height - .5) * -10;
		const image = event.currentTarget.querySelector("[data-depth]");
		image?.style.setProperty("--shift-x", `${x}px`);
		image?.style.setProperty("--shift-y", `${y}px`);
	};
	const resetDepth = (event) => {
		const image = event.currentTarget.querySelector("[data-depth]");
		image?.style.setProperty("--shift-x", "0px");
		image?.style.setProperty("--shift-y", "0px");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "marble-water min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntroSequence, {}),
			preview.overlay,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-[92svh] flex-col overflow-hidden border-b border-border",
				onPointerMove: handleDepth,
				onPointerLeave: resetDepth,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						"data-depth": true,
						src: nil_hero_default,
						alt: "Nil Mobilya modern oturma odası koleksiyonu",
						width: 1920,
						height: 1280,
						className: "image-depth absolute inset-0 h-full w-full object-contain object-center [--depth-scale:1]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[linear-gradient(90deg,var(--background)_0%,color-mix(in_oklab,var(--background)_82%,transparent)_34%,color-mix(in_oklab,var(--background)_20%,transparent)_72%,color-mix(in_oklab,var(--background)_48%,transparent)_100%)]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "relative z-20 flex h-20 items-center justify-between border-b border-foreground/15 px-5 md:h-24 md:px-12 lg:px-20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#top",
								"aria-label": "Nil Mobilya ana sayfa",
								className: "font-display text-2xl font-medium uppercase text-foreground md:text-3xl",
								children: ["Nil ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: "Mobilya"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
								className: "hidden items-center gap-10 text-xs font-medium uppercase text-foreground/80 md:flex",
								"aria-label": "Ana menü",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#koleksiyon",
										className: "transition-colors hover:text-primary",
										children: "Koleksiyon"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#hikaye",
										className: "transition-colors hover:text-primary",
										children: "Hikâyemiz"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#iletisim",
										className: "transition-colors hover:text-primary",
										children: "İletişim"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "md:hidden",
								onClick: () => setMenuOpen((value) => !value),
								"aria-label": menuOpen ? "Menüyü kapat" : "Menüyü aç",
								children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
							})
						]
					}),
					menuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "absolute inset-x-0 top-20 z-30 flex flex-col border-b border-border bg-background p-6 text-sm uppercase md:hidden",
						"aria-label": "Mobil menü",
						children: [
							["Koleksiyon", "#koleksiyon"],
							["Hikâyemiz", "#hikaye"],
							["İletişim", "#iletisim"]
						].map(([label, href]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href,
							onClick: () => setMenuOpen(false),
							className: "border-b border-border py-5 last:border-0",
							children: label
						}, href))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						id: "top",
						className: "relative z-10 flex flex-1 items-end px-5 pb-12 pt-24 md:px-12 md:pb-16 lg:px-20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "reveal-up max-w-xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mb-5 text-[10px] font-semibold uppercase text-primary md:text-xs",
									children: "Est. 2008 · İstanbul"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "font-display text-6xl font-medium leading-[0.86] text-foreground sm:text-7xl md:text-8xl lg:text-[7.5rem]",
									children: [
										"Nil",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"Mobilya"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-7 max-w-md text-sm font-light leading-7 text-foreground/75 md:text-base",
									children: "Modern çizgileri yüksek kaliteli malzemeler ve ustalıkla buluşturarak, zamana değer katan yaşam alanları tasarlıyoruz."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap items-center gap-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "gold",
										size: "lg",
										className: "h-12 px-6 text-xs uppercase",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: "#koleksiyon",
											children: ["Koleksiyonu keşfet ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: "#hikaye",
										className: "flex items-center gap-2 text-xs uppercase text-foreground/80 transition-colors hover:text-primary",
										children: ["Tasarım yaklaşımımız ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3" })]
									})]
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 flex items-center justify-between border-t border-foreground/15 px-5 py-4 text-[9px] uppercase text-foreground/60 md:px-12 lg:px-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Form · Doku · Denge" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Özgün yaşam alanları" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "koleksiyon",
				className: "px-5 py-20 md:px-12 md:py-28 lg:px-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-12 flex items-end justify-between border-b border-border pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-[10px] font-semibold uppercase text-primary",
						children: "Seçkimiz"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-4xl md:text-6xl",
						children: "Yeni Koleksiyon"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden text-xs text-muted-foreground md:block",
						children: "2026 / 01—03"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-8 md:grid-cols-2 lg:grid-cols-12",
					children: collections.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
						className: item.number === "01" ? "group md:col-span-2 lg:col-span-6" : "group lg:col-span-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/koleksiyon/$slug",
							params: { slug: item.slug },
							className: "block cursor-pointer",
							"aria-label": `${item.title} koleksiyonunu görüntüle`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `overflow-hidden bg-surface-raised ${index === 0 ? "aspect-[5/4] lg:aspect-[4/5]" : "aspect-[4/5]"}`,
								onPointerMove: handleDepth,
								onPointerEnter: (event) => {
									if (event.pointerType === "touch") return;
									preview.open({
										src: item.hero,
										alt: `Nil Mobilya ${item.title.toLocaleLowerCase("tr-TR")} koleksiyonu`,
										title: `${item.number} · ${item.title}`,
										lines: [item.note, item.description]
									}, event.currentTarget);
								},
								onPointerLeave: (event) => {
									resetDepth(event);
									preview.close();
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									"data-depth": true,
									src: item.hero,
									alt: `Nil Mobilya ${item.title.toLocaleLowerCase("tr-TR")} koleksiyonu`,
									width: 1024,
									height: 1280,
									loading: "lazy",
									className: "image-depth h-full w-full object-contain [--depth-scale:1] saturate-[.8] group-hover:saturate-100"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between border-b border-border py-5 transition-colors group-hover:border-primary/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] text-primary",
										children: item.number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-1 font-display text-3xl transition-colors group-hover:text-primary",
										children: item.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-xs text-muted-foreground",
										children: item.note
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "mt-2 size-5 text-primary transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" })]
							})]
						})
					}, item.slug))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MaterialsSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReviewsMarquee, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				id: "hikaye",
				className: "grid border-y border-border md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-h-[420px] items-center px-5 py-20 md:px-12 lg:px-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-5 text-[10px] font-semibold uppercase text-primary",
							children: "Nil yaklaşımı"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-4xl leading-tight md:text-6xl",
							children: "Güzellik, iyi yaşamın sessiz bir parçasıdır."
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-h-[360px] items-end bg-surface-raised px-5 py-16 md:px-12 lg:px-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-lg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-7xl text-primary/45",
							children: "N"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-8 text-sm font-light leading-7 text-ink-soft md:text-base",
							children: "Her parçayı geçici eğilimlerden uzak, günlük hayatla birlikte güzelleşecek bir obje olarak ele alıyoruz. Malzemeye saygı, dengeli oranlar ve incelikli işçilik tasarımlarımızın temelini oluşturuyor."
						})]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b border-border px-5 py-16 md:px-12 md:py-24 lg:px-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid border border-primary/30 bg-surface-raised md:grid-cols-[minmax(0,1.4fr)_minmax(280px,0.6fr)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-border p-7 md:border-b-0 md:border-r md:p-12 lg:p-16",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-4 text-[10px] font-semibold uppercase text-primary",
								children: "Özel üretim"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "max-w-2xl font-display text-4xl leading-tight md:text-6xl",
								children: "Size özel, seçkin ölçekte üretim."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-xl text-sm font-light leading-7 text-ink-soft md:text-base",
								children: "Bireysel müşteriler için yalnızca yüksek segment özel tasarımlar veya adetli üretim projeleri kabul ediyoruz. Aradığınız çalışma bu kapsama uyuyorsa bizimle iletişime geçin."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col justify-end gap-4 p-7 md:p-10 lg:p-12",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase text-muted-foreground",
								children: "Özel proje hattı"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "gold",
								size: "lg",
								className: "h-12 w-full justify-start px-5 text-xs uppercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "tel:+902120000000",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), " 0 (212) 000 00 00"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "goldOutline",
								size: "lg",
								className: "h-12 w-full justify-start px-5 text-xs lowercase",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "mailto:ozel@nilmobilya.com",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-4" }), " ozel@nilmobilya.com"]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] leading-5 text-muted-foreground",
								children: "Prototip iletişim bilgileri"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				id: "iletisim",
				className: "px-5 py-16 md:px-12 md:py-20 lg:px-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-between gap-12 md:flex-row md:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-xs uppercase text-primary",
						children: "Yaşam alanınızı birlikte kuralım"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-5xl md:text-7xl",
						children: "Bizimle tanışın."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "goldOutline",
						size: "lg",
						className: "h-12 self-start px-6 text-xs uppercase md:self-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#koleksiyon",
							children: ["Koleksiyonu incele ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-16 flex flex-col gap-3 border-t border-border pt-6 text-[10px] uppercase text-muted-foreground md:flex-row md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 2026 Nil Mobilya" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Modern · Nitelikli · Zamansız" })]
				})]
			})
		]
	});
}
//#endregion
export { Index as component };
