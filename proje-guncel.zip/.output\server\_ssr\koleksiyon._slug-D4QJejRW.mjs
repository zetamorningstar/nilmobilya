import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Route } from "./koleksiyon._slug-C3cXIkHN.mjs";
import { t as Button } from "./button-DurlFYMP.mjs";
import { t as useHoverPreview } from "./hover-preview-CQuwEoW5.mjs";
import { c as ArrowUpRight, l as ArrowLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/koleksiyon._slug-D4QJejRW.js
var import_jsx_runtime = require_jsx_runtime();
function handleDepth(event) {
	if (event.pointerType === "touch") return;
	const bounds = event.currentTarget.getBoundingClientRect();
	const x = ((event.clientX - bounds.left) / bounds.width - .5) * -14;
	const y = ((event.clientY - bounds.top) / bounds.height - .5) * -10;
	const image = event.currentTarget.querySelector("[data-depth]");
	image?.style.setProperty("--shift-x", `${x}px`);
	image?.style.setProperty("--shift-y", `${y}px`);
}
function resetDepth(event) {
	const image = event.currentTarget.querySelector("[data-depth]");
	image?.style.setProperty("--shift-x", "0px");
	image?.style.setProperty("--shift-y", "0px");
}
function CollectionDetail({ collection }) {
	const preview = useHoverPreview();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			preview.overlay,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-20 items-center justify-between border-b border-foreground/15 px-5 md:h-24 md:px-12 lg:px-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					"aria-label": "Nil Mobilya ana sayfa",
					className: "font-display text-2xl font-medium uppercase text-foreground md:text-3xl",
					children: ["Nil ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary",
						children: "Mobilya"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2 text-xs font-medium uppercase text-foreground/80 transition-colors hover:text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3" }), " Ana sayfa"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-[68svh] flex-col justify-end overflow-hidden border-b border-border",
				onPointerMove: handleDepth,
				onPointerLeave: resetDepth,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						"data-depth": true,
						src: collection.hero,
						alt: collection.heroAlt,
						width: 1024,
						height: 1280,
						className: "image-depth absolute inset-0 h-full w-full object-contain [--depth-scale:1]",
						style: { objectPosition: collection.heroFocus }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-[linear-gradient(0deg,var(--background)_4%,color-mix(in_oklab,var(--background)_55%,transparent)_45%,color-mix(in_oklab,var(--background)_18%,transparent)_100%)]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10 px-5 pb-12 md:px-12 md:pb-16 lg:px-20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "reveal-up mb-4 text-[10px] font-semibold uppercase text-primary md:text-xs",
								children: ["Koleksiyon ", collection.number]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "reveal-up font-display text-6xl font-medium leading-[0.9] text-foreground md:text-8xl",
								children: collection.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "reveal-up mt-4 text-sm font-light text-foreground/75 md:text-base",
								children: collection.note
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-b border-border px-5 py-16 md:px-12 md:py-20 lg:px-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-10 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-lg font-display text-3xl leading-snug text-foreground md:text-4xl",
						children: collection.description
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-end justify-start md:justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "goldOutline",
							size: "lg",
							className: "h-12 px-6 text-xs uppercase",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								hash: "iletisim",
								children: ["Bu koleksiyonu yerinizde görün ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
							})
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-5 py-20 md:px-12 md:py-24 lg:px-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-12 flex items-end justify-between border-b border-border pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl md:text-5xl",
						children: "Parçalar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [collection.title, " · 2026"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-8 md:grid-cols-3",
					children: collection.products.map((product, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "group",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden bg-surface-raised aspect-[4/5]",
							onPointerMove: handleDepth,
							onPointerEnter: (event) => {
								if (event.pointerType === "touch") return;
								preview.open({
									src: product.image,
									alt: `Nil Mobilya ${collection.title.toLocaleLowerCase("tr-TR")} koleksiyonu — ${product.name}`,
									title: `0${index + 1} · ${product.name}`,
									lines: [product.material, `${collection.title} koleksiyonu · 2026`]
								}, event.currentTarget);
							},
							onPointerLeave: (event) => {
								resetDepth(event);
								preview.close();
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								"data-depth": true,
								src: product.image,
								alt: `Nil Mobilya ${collection.title.toLocaleLowerCase("tr-TR")} koleksiyonu — ${product.name}`,
								width: 1024,
								height: 1280,
								loading: index === 0 ? "eager" : "lazy",
								className: "image-depth h-full w-full object-contain [--depth-scale:1] saturate-[.8] group-hover:saturate-100"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between border-b border-border py-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] text-primary",
									children: ["0", index + 1]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-1 font-display text-2xl",
									children: product.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: product.material
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "mt-2 size-5 text-primary transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-1" })]
						})]
					}, product.name))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-t border-border px-5 py-16 md:px-12 md:py-20 lg:px-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-between gap-10 md:flex-row md:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-xs uppercase text-primary",
						children: "Diğer koleksiyonlar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-x-8 gap-y-3",
						children: [
							"oturma",
							"berjer",
							"yemek"
						].filter((slug) => slug !== collection.slug).map((slug) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/koleksiyon/$slug",
							params: { slug },
							className: "font-display text-3xl text-foreground/70 transition-colors hover:text-primary md:text-5xl",
							children: slug === "oturma" ? "Oturma" : slug === "berjer" ? "Berjer" : "Yemek"
						}, slug))
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "gold",
						size: "lg",
						className: "h-12 self-start px-6 text-xs uppercase md:self-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							hash: "koleksiyon",
							children: ["Tüm koleksiyon ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-16 flex flex-col gap-3 border-t border-border pt-6 text-[10px] uppercase text-muted-foreground md:flex-row md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 2026 Nil Mobilya" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Form · Doku · Denge" })]
				})]
			})
		]
	});
}
function CollectionRoute() {
	const { collection } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollectionDetail, { collection });
}
//#endregion
export { CollectionRoute as component };
