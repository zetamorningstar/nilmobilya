globalThis.__nitro_main__ = import.meta.url;
import { i as HTTPError, n as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"b7-HjXhj1SGMcdYVg0iK+FOcNBG5ek\"",
		"mtime": "2026-09-26T22:36:37.626Z",
		"size": 183,
		"path": "../public/favicon.svg"
	},
	"/assets/arrow-left-D5G_8Anu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b-aKnU/Ko/t9gVjl0d9IFeJ7f2C9E\"",
		"mtime": "2026-09-26T22:56:39.387Z",
		"size": 155,
		"path": "../public/assets/arrow-left-D5G_8Anu.js"
	},
	"/assets/collections-IUPuIXII.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9452-F2egkk6VVlbF2Z5YVdhU6epuWfo\"",
		"mtime": "2026-09-26T22:56:39.390Z",
		"size": 37970,
		"path": "../public/assets/collections-IUPuIXII.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-09-26T22:36:37.637Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/button-D0jtSMQY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"838c-nNVxP5nVcSAhXWy7zG1uyHd50gU\"",
		"mtime": "2026-09-26T22:56:39.388Z",
		"size": 33676,
		"path": "../public/assets/button-D0jtSMQY.js"
	},
	"/assets/hover-preview-cVgPYXaK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bda-ywYoZj8fl3wy1YPdYD4/7qUB5MM\"",
		"mtime": "2026-09-26T22:56:39.390Z",
		"size": 3034,
		"path": "../public/assets/hover-preview-cVgPYXaK.js"
	},
	"/assets/koleksiyon._slug-atQmmKLx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"480-Gs1eKsMZ3qY3hjahRBU4W727KJ0\"",
		"mtime": "2026-09-26T22:56:39.391Z",
		"size": 1152,
		"path": "../public/assets/koleksiyon._slug-atQmmKLx.js"
	},
	"/assets/koleksiyon._slug-Dlg-_GXr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17ae-HAZorDm8AdpwH5scliOs762gyw8\"",
		"mtime": "2026-09-26T22:56:39.391Z",
		"size": 6062,
		"path": "../public/assets/koleksiyon._slug-Dlg-_GXr.js"
	},
	"/assets/material-boucle-BRxvoS42.jpg": {
		"type": "image/jpeg",
		"etag": "\"27916-5oCR7MRSyYvunY7WevQH8mAw8C0\"",
		"mtime": "2026-09-26T22:56:39.393Z",
		"size": 162070,
		"path": "../public/assets/material-boucle-BRxvoS42.jpg"
	},
	"/assets/index-3Listjcj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"526e5-CnnwAhrJ5TD5t9WjFR1KR5XFa3Y\"",
		"mtime": "2026-09-26T22:56:39.387Z",
		"size": 337637,
		"path": "../public/assets/index-3Listjcj.js"
	},
	"/assets/material-ceviz-BIRs5vjs.jpg": {
		"type": "image/jpeg",
		"etag": "\"32655-RZ7A7td3Px8GQ8BrUPOrtk1vkSs\"",
		"mtime": "2026-09-26T22:56:39.394Z",
		"size": 206421,
		"path": "../public/assets/material-ceviz-BIRs5vjs.jpg"
	},
	"/assets/material-kadife-DTEuTV9U.jpg": {
		"type": "image/jpeg",
		"etag": "\"26280-eeEBzmA9nYx+rRVgJkfUQkobpsk\"",
		"mtime": "2026-09-26T22:56:39.396Z",
		"size": 156288,
		"path": "../public/assets/material-kadife-DTEuTV9U.jpg"
	},
	"/assets/material-deri-kQzExQNq.jpg": {
		"type": "image/jpeg",
		"etag": "\"42f05-dL4ahWt4D3ZxOGxQad2c1apFgSs\"",
		"mtime": "2026-09-26T22:56:39.395Z",
		"size": 274181,
		"path": "../public/assets/material-deri-kQzExQNq.jpg"
	},
	"/assets/material-pirinc-7jvuJ_qE.jpg": {
		"type": "image/jpeg",
		"etag": "\"23e52-3nlpDG86TGO3CI1kCcx3ahH3itI\"",
		"mtime": "2026-09-26T22:56:39.397Z",
		"size": 147026,
		"path": "../public/assets/material-pirinc-7jvuJ_qE.jpg"
	},
	"/assets/material-mermer-CoBcAWMW.jpg": {
		"type": "image/jpeg",
		"etag": "\"1a7ca-GTrPeXSVcWVCrVoDbRh7DibJ5QQ\"",
		"mtime": "2026-09-26T22:56:39.396Z",
		"size": 108490,
		"path": "../public/assets/material-mermer-CoBcAWMW.jpg"
	},
	"/assets/nil-chair-2-fxEDGw4n.jpg": {
		"type": "image/jpeg",
		"etag": "\"22421-Y8TAo1qjpKU2OKM9LC4sUA9j7uQ\"",
		"mtime": "2026-09-26T22:56:39.398Z",
		"size": 140321,
		"path": "../public/assets/nil-chair-2-fxEDGw4n.jpg"
	},
	"/assets/nil-chair-3-CXmvu_17.jpg": {
		"type": "image/jpeg",
		"etag": "\"1f361-B/NMzsV5aw/V1iIm/9y1E1kbLPI\"",
		"mtime": "2026-09-26T22:56:39.398Z",
		"size": 127841,
		"path": "../public/assets/nil-chair-3-CXmvu_17.jpg"
	},
	"/assets/nil-chair-CbYvzqfZ.jpg": {
		"type": "image/jpeg",
		"etag": "\"2840f-lui57secp/cT31V5vsUDT9Ck6Mo\"",
		"mtime": "2026-09-26T22:56:39.399Z",
		"size": 164879,
		"path": "../public/assets/nil-chair-CbYvzqfZ.jpg"
	},
	"/assets/nil-dining-2-D8n6UrQ2.jpg": {
		"type": "image/jpeg",
		"etag": "\"1de57-teQfpQNfY7tBKOI4G/uUX+GWMmI\"",
		"mtime": "2026-09-26T22:56:39.400Z",
		"size": 122455,
		"path": "../public/assets/nil-dining-2-D8n6UrQ2.jpg"
	},
	"/assets/nil-dining-3-BVVOqgya.jpg": {
		"type": "image/jpeg",
		"etag": "\"1960e-7Fu/j0WcSZngV2mLt228yG2v1ow\"",
		"mtime": "2026-09-26T22:56:39.400Z",
		"size": 103950,
		"path": "../public/assets/nil-dining-3-BVVOqgya.jpg"
	},
	"/assets/nil-dining-NrH7v7DA.jpg": {
		"type": "image/jpeg",
		"etag": "\"35a52-3tJDhzU/r3xJL7P43RMuBQgHGWc\"",
		"mtime": "2026-09-26T22:56:39.402Z",
		"size": 219730,
		"path": "../public/assets/nil-dining-NrH7v7DA.jpg"
	},
	"/assets/nil-sofa-3-DP5Pd3Xs.jpg": {
		"type": "image/jpeg",
		"etag": "\"1d98c-onuMLYlE0QTY/Eby2k/l251k0os\"",
		"mtime": "2026-09-26T22:56:39.406Z",
		"size": 121228,
		"path": "../public/assets/nil-sofa-3-DP5Pd3Xs.jpg"
	},
	"/assets/nil-hero-DVXsMWlB.jpg": {
		"type": "image/jpeg",
		"etag": "\"49500-uYSMAqaAv+VGQGT95xzH3qeCbts\"",
		"mtime": "2026-09-26T22:56:39.403Z",
		"size": 300288,
		"path": "../public/assets/nil-hero-DVXsMWlB.jpg"
	},
	"/assets/nil-sofa-2-Cm2LnAMK.jpg": {
		"type": "image/jpeg",
		"etag": "\"22b19-5fVA/D3RrZ2g5MA/i0nFJM062L4\"",
		"mtime": "2026-09-26T22:56:39.405Z",
		"size": 142105,
		"path": "../public/assets/nil-sofa-2-Cm2LnAMK.jpg"
	},
	"/assets/nil-sofa-DzyBqoyB.jpg": {
		"type": "image/jpeg",
		"etag": "\"32ace-+7fuyuguz8dfJHNQuLstvae3XIs\"",
		"mtime": "2026-09-26T22:56:39.406Z",
		"size": 207566,
		"path": "../public/assets/nil-sofa-DzyBqoyB.jpg"
	},
	"/assets/odanda-dene-CdWGSqeJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e4e-u3jHDWSpBAPQg6MmAg/5LPHyuPM\"",
		"mtime": "2026-09-26T22:56:39.392Z",
		"size": 7758,
		"path": "../public/assets/odanda-dene-CdWGSqeJ.js"
	},
	"/assets/preload-helper-RWICzLV4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1839-J5w8ChBfH0VlTSCUdHIv09ga8xE\"",
		"mtime": "2026-09-26T22:56:39.392Z",
		"size": 6201,
		"path": "../public/assets/preload-helper-RWICzLV4.js"
	},
	"/assets/routes-D23T1_I8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b96-0PTSGTTy7G5DaWyoRdTxhqhy0NM\"",
		"mtime": "2026-09-26T22:56:39.393Z",
		"size": 19350,
		"path": "../public/assets/routes-D23T1_I8.js"
	},
	"/assets/styles-w2Jju35-.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17417-cosWMYvexcdE3ijfh1RHxYUrEUg\"",
		"mtime": "2026-09-26T22:56:39.407Z",
		"size": 95255,
		"path": "../public/assets/styles-w2Jju35-.css"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_YPk9uT = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_YPk9uT
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
