import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, g as useRouter, h as Link, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { t as Route$4 } from "./koleksiyon._slug-C3cXIkHN.mjs";
import { t as Route$5 } from "./odanda-dene-DSbUGJ1c.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CMCXws1C.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-w2Jju35-.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$3 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Nil Mobilya" },
			{
				name: "description",
				content: "Modern yaşam alanları için yüksek kaliteli mobilya tasarımları."
			},
			{
				name: "author",
				content: "Nil Mobilya"
			},
			{
				property: "og:title",
				content: "Nil Mobilya"
			},
			{
				property: "og:description",
				content: "Modern yaşam alanları için yüksek kaliteli mobilya tasarımları."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&family=Manrope:wght@300;400;500;600&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$3.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter = () => import("./routes--kyVBd_B.mjs");
var Route$2 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Nil Mobilya | Modern ve Yüksek Kaliteli Mobilya" },
		{
			name: "description",
			content: "Nil Mobilya ile modern çizgiler, seçkin malzemeler ve yüksek kaliteli işçilik yaşam alanlarınıza değer katsın."
		},
		{
			property: "og:title",
			content: "Nil Mobilya | Zamansız Yaşam Alanları"
		},
		{
			property: "og:description",
			content: "Modern çizgileri yüksek kaliteli işçilikle buluşturan seçkin mobilya koleksiyonu."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function describeSpot(spot) {
	if (!spot) return "in the most natural free area of the room";
	const horizontal = spot.x < 33 ? "left" : spot.x > 66 ? "right" : "horizontally centered";
	const vertical = spot.y < 40 ? "far / background" : spot.y > 72 ? "near / foreground" : "middle-depth";
	return `at roughly ${Math.round(spot.x)}% from the left and ${Math.round(spot.y)}% from the top of the photo (${horizontal} side, ${vertical} part of the room)`;
}
var Route$1 = createFileRoute("/api/room-compose")({ server: { handlers: { POST: async ({ request }) => {
	const key = processModule.env["LOVABLE_API_KEY"];
	if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });
	const { room, furniture, name = "furniture piece", spot = null, note = "" } = await request.json();
	if (!room?.startsWith("data:image/") || !furniture?.startsWith("data:image/")) return new Response(JSON.stringify({ error: "Oda fotoğrafı ve mobilya görseli gerekli" }), {
		status: 400,
		headers: { "Content-Type": "application/json" }
	});
	const prompt = [
		"You are given two images. IMAGE 1 is a photo of a real room. IMAGE 2 is a furniture product photo",
		`("${name}").`,
		"Edit IMAGE 1 so that the furniture piece from IMAGE 2 is placed inside that room",
		`${describeSpot(spot)}.`,
		"Keep the room exactly as it is: same walls, floor, windows, existing objects, camera angle, perspective and lighting.",
		"Only add the furniture piece. Match its scale to the room, align it to the floor plane and perspective,",
		"relight it with the room's own light direction and color temperature, and add a realistic contact shadow.",
		"Keep the furniture's real design, materials and colors from IMAGE 2. Photorealistic interior photograph result, same dimensions as IMAGE 1.",
		note ? `Additional request from the client: ${note}` : ""
	].filter(Boolean).join(" ");
	const upstream = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${key}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			model: "google/gemini-3-pro-image",
			messages: [{
				role: "user",
				content: [
					{
						type: "text",
						text: prompt
					},
					{
						type: "image_url",
						image_url: { url: room }
					},
					{
						type: "image_url",
						image_url: { url: furniture }
					}
				]
			}],
			modalities: ["image", "text"]
		})
	});
	if (!upstream.ok) {
		const text = await upstream.text().catch(() => "");
		return new Response(JSON.stringify({ error: text || "Görsel oluşturulamadı" }), {
			status: upstream.status,
			headers: { "Content-Type": "application/json" }
		});
	}
	const b64 = (await upstream.json()).data?.[0]?.b64_json;
	if (!b64) return new Response(JSON.stringify({ error: "Görsel oluşturulamadı" }), {
		status: 502,
		headers: { "Content-Type": "application/json" }
	});
	return Response.json({ image: `data:image/png;base64,${b64}` });
} } } });
var Route = createFileRoute("/api/spin-frame")({ server: { handlers: { POST: async ({ request }) => {
	const key = processModule.env["LOVABLE_API_KEY"];
	if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });
	const { image, angle = 0, name = "furniture piece" } = await request.json();
	if (!image || !image.startsWith("data:image/")) return new Response(JSON.stringify({ error: "Geçersiz görsel" }), {
		status: 400,
		headers: { "Content-Type": "application/json" }
	});
	const prompt = [
		`Render the exact same furniture piece shown in the image ("${name}"), rotated ${angle} degrees around its vertical axis,`,
		"as if photographed on a turntable. Keep the identical design, proportions, materials, upholstery texture, colors, stitching and legs.",
		"Do not redesign or replace the piece. Studio product photograph, dark charcoal seamless background, soft warm key light from the upper left,",
		"the piece centered, full piece visible, same camera height and distance, same framing and image dimensions as the reference."
	].join(" ");
	const upstream = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${key}`,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({
			model: "google/gemini-3.1-flash-image",
			messages: [{
				role: "user",
				content: [{
					type: "text",
					text: prompt
				}, {
					type: "image_url",
					image_url: { url: image }
				}]
			}],
			modalities: ["image", "text"]
		})
	});
	if (!upstream.ok) {
		const text = await upstream.text().catch(() => "");
		return new Response(JSON.stringify({ error: text || "Görsel üretilemedi" }), {
			status: upstream.status,
			headers: { "Content-Type": "application/json" }
		});
	}
	const b64 = (await upstream.json()).data?.[0]?.b64_json;
	if (!b64) return new Response(JSON.stringify({ error: "Görsel üretilemedi" }), {
		status: 502,
		headers: { "Content-Type": "application/json" }
	});
	return Response.json({ image: `data:image/png;base64,${b64}` });
} } } });
var rootRouteChildren = {
	IndexRoute: Route$2.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$3
	}),
	OdandaDeneRoute: Route$5.update({
		id: "/odanda-dene",
		path: "/odanda-dene",
		getParentRoute: () => Route$3
	}),
	ApiRoomComposeRoute: Route$1.update({
		id: "/api/room-compose",
		path: "/api/room-compose",
		getParentRoute: () => Route$3
	}),
	ApiSpinFrameRoute: Route.update({
		id: "/api/spin-frame",
		path: "/api/spin-frame",
		getParentRoute: () => Route$3
	}),
	KoleksiyonSlugRoute: Route$4.update({
		id: "/koleksiyon/$slug",
		path: "/koleksiyon/$slug",
		getParentRoute: () => Route$3
	})
};
var routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
