//#region node_modules/.nitro/vite/services/ssr/assets/collections-vvy82Ul_.js
var nil_chair_default = "/assets/nil-chair-CbYvzqfZ.jpg";
var nil_chair_2_default = "/assets/nil-chair-2-fxEDGw4n.jpg";
var nil_chair_3_default = "/assets/nil-chair-3-CXmvu_17.jpg";
var nil_dining_default = "/assets/nil-dining-NrH7v7DA.jpg";
var nil_dining_2_default = "/assets/nil-dining-2-D8n6UrQ2.jpg";
var nil_dining_3_default = "/assets/nil-dining-3-BVVOqgya.jpg";
var nil_sofa_default = "/assets/nil-sofa-DzyBqoyB.jpg";
var collections = [
	{
		slug: "oturma",
		number: "01",
		title: "Oturma",
		note: "Rahatlığın yalın formu",
		description: "Oturma koleksiyonu, günün her anında dokunulmak için tasarlanan derin otururlar ve yumuşak hatlarla salonun merkezine yerleşen sakin bir zarafet sunar.",
		hero: nil_sofa_default,
		heroAlt: "Nil Mobilya oturma koleksiyonu — modern oturma grubu",
		heroFocus: "62% center",
		products: [
			{
				name: "Bulut Oturma Grubu",
				material: "Bouclé kumaş · Ceviz ayak",
				image: nil_sofa_default
			},
			{
				name: "Modüler Köşe Takımı",
				material: "Yumuşak dokulu kumaş",
				image: "/assets/nil-sofa-2-Cm2LnAMK.jpg"
			},
			{
				name: "Kavisli Kadife Sofa",
				material: "Kadife · Pirinç detay",
				image: "/assets/nil-sofa-3-DP5Pd3Xs.jpg"
			}
		]
	},
	{
		slug: "berjer",
		number: "02",
		title: "Berjer",
		note: "İmza niteliğinde detaylar",
		description: "Berjer koleksiyonu; köşeyi, okuma ışığını ve sessiz anları düşünerek tasarlandı. Her parça, mekânda bağımsız bir obje gibi durur.",
		hero: nil_chair_default,
		heroAlt: "Nil Mobilya berjer koleksiyonu — okuma köşesi berjeri",
		heroFocus: "55% center",
		products: [
			{
				name: "Kadife Berjer",
				material: "Kadife döşeme · Ahşap ayak",
				image: nil_chair_default
			},
			{
				name: "Okuma Köşesi Berjeri",
				material: "Kadife · Pirinç lamba uyumu",
				image: nil_chair_2_default
			},
			{
				name: "Heykelsi Bouclé Berjer",
				material: "Bouclé · Döner taban",
				image: nil_chair_3_default
			}
		]
	},
	{
		slug: "yemek",
		number: "03",
		title: "Yemek",
		note: "Bir araya gelmenin zarafeti",
		description: "Yemek koleksiyonu; uzun sofralar ve paylaşılan anlar için dengeli oranlar, doğal ahşap ve incelikli döşemelerle üretilir.",
		hero: nil_dining_default,
		heroAlt: "Nil Mobilya yemek koleksiyonu — ceviz yemek masası",
		heroFocus: "50% center",
		products: [
			{
				name: "Ceviz Yemek Masası",
				material: "Masif ceviz",
				image: nil_dining_default
			},
			{
				name: "Zemin Ayaklı Yemek Takımı",
				material: "Ceviz · Döşemeli sandalyeler",
				image: nil_dining_2_default
			},
			{
				name: "Deri Kaplama Sandalye",
				material: "Deri · Ceviz iskelet",
				image: nil_dining_3_default
			}
		]
	}
];
function getCollection(slug) {
	return collections.find((collection) => collection.slug === slug);
}
//#endregion
export { getCollection as n, collections as t };
