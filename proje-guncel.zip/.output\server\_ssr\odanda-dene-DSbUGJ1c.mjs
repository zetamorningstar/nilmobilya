import { f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/odanda-dene-DSbUGJ1c.js
var $$splitComponentImporter = () => import("./odanda-dene-CtlVKxAb.mjs");
var Route = createFileRoute("/odanda-dene")({
	validateSearch: (search) => ({ parca: typeof search["parca"] === "string" ? search["parca"] : void 0 }),
	head: () => ({ meta: [
		{ title: "Odanızda Deneyin | Nil Mobilya" },
		{
			name: "description",
			content: "Odanızın fotoğrafını yükleyin, beğendiğiniz Nil Mobilya parçasını seçin ve yapay zekâ ile evinizde nasıl duracağını görün."
		},
		{
			property: "og:title",
			content: "Odanızda Deneyin | Nil Mobilya"
		},
		{
			property: "og:description",
			content: "Yapay zekâ ile mobilyayı kendi odanızın fotoğrafında görün."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
