import { n as __toESM } from "../_runtime.mjs";
import { t as collections } from "./collections-vvy82Ul_.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-DurlFYMP.mjs";
import { l as ArrowLeft, n as Upload, r as Sparkles, s as LoaderCircle } from "../_libs/lucide-react.mjs";
import { t as Route } from "./odanda-dene-DSbUGJ1c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/odanda-dene-CtlVKxAb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MAX_EDGE = 1024;
/** Load any image URL (bundled asset included) and return a downscaled JPEG data URL. */
async function toDataUrl(src, maxEdge = MAX_EDGE) {
	return drawToDataUrl(await loadImage(src), maxEdge);
}
/** Read a user-selected file into a downscaled JPEG data URL. */
async function fileToDataUrl(file, maxEdge = 1280) {
	return drawToDataUrl(await loadImage(await new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(/* @__PURE__ */ new Error("Dosya okunamadı"));
		reader.readAsDataURL(file);
	})), maxEdge);
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const image = new Image();
		image.crossOrigin = "anonymous";
		image.onload = () => resolve(image);
		image.onerror = () => reject(/* @__PURE__ */ new Error("Görsel yüklenemedi"));
		image.src = src;
	});
}
function drawToDataUrl(image, maxEdge) {
	const scale = Math.min(1, maxEdge / Math.max(image.naturalWidth, image.naturalHeight));
	const canvas = document.createElement("canvas");
	canvas.width = Math.round(image.naturalWidth * scale);
	canvas.height = Math.round(image.naturalHeight * scale);
	const context = canvas.getContext("2d");
	if (!context) throw new Error("Görsel işlenemedi");
	context.drawImage(image, 0, 0, canvas.width, canvas.height);
	return canvas.toDataURL("image/jpeg", .9);
}
var pieces = collections.flatMap((collection) => collection.products.map((product) => ({
	key: `${collection.slug}-${product.name}`,
	name: product.name,
	material: product.material,
	image: product.image,
	collection: collection.title
})));
function TryAtHome() {
	const { parca } = Route.useSearch();
	const initial = (0, import_react.useMemo)(() => pieces.find((piece) => piece.name === parca) ?? pieces[0], [parca]);
	const [selected, setSelected] = (0, import_react.useState)(initial);
	const [room, setRoom] = (0, import_react.useState)(null);
	const [spot, setSpot] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const fileInput = (0, import_react.useRef)(null);
	async function onFile(file) {
		if (!file) return;
		setError(null);
		setResult(null);
		setSpot(null);
		try {
			setRoom(await fileToDataUrl(file));
		} catch {
			setError("Fotoğraf okunamadı. Lütfen başka bir görsel deneyin.");
		}
	}
	async function generate() {
		if (!room) return;
		setLoading(true);
		setError(null);
		setResult(null);
		try {
			const furniture = await toDataUrl(selected.image);
			const response = await fetch("/api/room-compose", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					room,
					furniture,
					name: selected.name,
					spot,
					note
				})
			});
			if (!response.ok) {
				const body = await response.json().catch(() => ({}));
				throw new Error(response.status === 402 ? "AI kredisi tükendi. Devam etmek için kredi ekleyin." : body.error || "Görsel oluşturulamadı.");
			}
			const data = await response.json();
			setResult(data.image);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Bir sorun oluştu.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-screen bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex h-20 items-center justify-between border-b border-foreground/15 px-5 md:h-24 md:px-12 lg:px-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "font-display text-2xl font-medium uppercase md:text-3xl",
					children: ["Nil ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-primary",
						children: "Mobilya"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2 text-xs font-medium uppercase text-foreground/80 transition-colors hover:text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3" }), " Ana sayfa"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "px-5 pb-10 pt-14 md:px-12 lg:px-20",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-[10px] font-semibold uppercase tracking-[0.22em] text-primary",
						children: "Yapay zekâ ile deneyin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "max-w-3xl font-display text-5xl leading-[0.95] md:text-7xl",
						children: "Beğendiğiniz parça evinizde nasıl durur?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 max-w-xl text-sm font-light leading-7 text-foreground/75",
						children: "Odanızın fotoğrafını yükleyin, parçayı seçin ve yerleşmesini istediğiniz noktaya dokunun. Gerisini yapay zekâ hallediyor."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-10 px-5 pb-24 md:px-12 lg:grid-cols-2 lg:px-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-3 text-xs uppercase text-primary",
								children: "01 · Oda fotoğrafınız"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								ref: fileInput,
								type: "file",
								accept: "image/*",
								className: "hidden",
								onChange: (event) => onFile(event.target.files?.[0])
							}),
							!room ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => fileInput.current?.click(),
								className: "flex aspect-[4/3] w-full flex-col items-center justify-center gap-3 border border-dashed border-primary/40 bg-surface-raised text-sm text-ink-soft transition-colors hover:border-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-6 text-primary" }), "Odanızın fotoğrafını yükleyin"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: "relative block w-full cursor-crosshair overflow-hidden border border-border",
									onClick: (event) => {
										const bounds = event.currentTarget.getBoundingClientRect();
										setSpot({
											x: (event.clientX - bounds.left) / bounds.width * 100,
											y: (event.clientY - bounds.top) / bounds.height * 100
										});
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: room,
										alt: "Yüklenen oda fotoğrafı",
										className: "w-full"
									}), spot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "pointer-events-none absolute size-6 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-primary bg-primary/25",
										style: {
											left: `${spot.x}%`,
											top: `${spot.y}%`
										}
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: spot ? "Yerleşim noktası seçildi." : "Fotoğrafta bir nokta seçin." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => fileInput.current?.click(),
										className: "uppercase text-primary hover:underline",
										children: "Değiştir"
									})]
								})]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-xs uppercase text-primary",
							children: "02 · Parça seçimi"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-3",
							children: pieces.map((piece) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setSelected(piece),
								className: "group text-left",
								"aria-pressed": piece.key === selected.key,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block aspect-[4/5] overflow-hidden border",
									style: { borderColor: piece.key === selected.key ? "var(--color-primary)" : "var(--color-border)" },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: piece.image,
										alt: piece.name,
										className: "h-full w-full object-contain"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-2 block text-[11px] leading-4 text-foreground/80",
									children: piece.name
								})]
							}, piece.key))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-xs uppercase text-primary",
							children: "03 · Notunuz (opsiyonel)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: note,
							onChange: (event) => setNote(event.target.value),
							rows: 3,
							placeholder: "Örn. pencereye dönük dursun, halının üstünde olsun",
							className: "w-full resize-none border border-border bg-surface-raised p-4 text-sm text-foreground outline-none placeholder:text-muted-foreground focus:border-primary"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "gold",
							size: "lg",
							className: "h-12 w-full px-6 text-xs uppercase",
							disabled: !room || loading,
							onClick: generate,
							children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), loading ? "Odanız hazırlanıyor" : "Odamda göster"]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-destructive",
							children: error
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:sticky lg:top-10 lg:self-start",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-xs uppercase text-primary",
							children: "Sonuç"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-h-[320px] items-center justify-center border border-border bg-surface-raised p-4",
							children: result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: result,
								alt: `${selected.name} odanızda`,
								className: "w-full"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-xs text-center text-xs font-light leading-6 text-muted-foreground",
								children: loading ? "Yapay zekâ parçayı odanızın ışığına ve perspektifine yerleştiriyor…" : "Oluşturduğunuz görsel burada belirecek."
							})
						}),
						result && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: result,
							download: `nil-mobilya-${selected.name}.png`,
							className: "mt-4 inline-block text-xs uppercase text-primary hover:underline",
							children: "Görseli indir"
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { TryAtHome as component };
