//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CqAVkRni.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/can/Desktop/nilmobilya/gilded-glow-rooms-main/src/routes/__root.tsx",
		children: [
			"/",
			"/odanda-dene",
			"/api/room-compose",
			"/api/spin-frame",
			"/koleksiyon/$slug"
		],
		preloads: [
			"/assets/index-3Listjcj.js",
			"/assets/collections-IUPuIXII.js",
			"/assets/koleksiyon._slug-atQmmKLx.js",
			"/assets/preload-helper-RWICzLV4.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-3Listjcj.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/can/Desktop/nilmobilya/gilded-glow-rooms-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D23T1_I8.js",
			"/assets/button-D0jtSMQY.js",
			"/assets/hover-preview-cVgPYXaK.js"
		]
	},
	"/odanda-dene": {
		filePath: "C:/Users/can/Desktop/nilmobilya/gilded-glow-rooms-main/src/routes/odanda-dene.tsx",
		children: void 0,
		preloads: [
			"/assets/odanda-dene-CdWGSqeJ.js",
			"/assets/button-D0jtSMQY.js",
			"/assets/arrow-left-D5G_8Anu.js"
		]
	},
	"/koleksiyon/$slug": {
		filePath: "C:/Users/can/Desktop/nilmobilya/gilded-glow-rooms-main/src/routes/koleksiyon.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/koleksiyon._slug-Dlg-_GXr.js",
			"/assets/button-D0jtSMQY.js",
			"/assets/arrow-left-D5G_8Anu.js",
			"/assets/hover-preview-cVgPYXaK.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
