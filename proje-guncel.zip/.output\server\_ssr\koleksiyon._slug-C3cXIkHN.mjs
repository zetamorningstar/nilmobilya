import { n as getCollection } from "./collections-vvy82Ul_.mjs";
import { A as notFound, f as lazyRouteComponent, p as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/koleksiyon._slug-C3cXIkHN.js
var $$splitComponentImporter = () => import("./koleksiyon._slug-D4QJejRW.mjs");
var Route = createFileRoute("/koleksiyon/$slug")({
	loader: ({ params }) => {
		const collection = getCollection(params.slug);
		if (!collection) throw notFound();
		return { collection };
	},
	head: ({ loaderData }) => {
		if (!loaderData) return { meta: [{ title: "Koleksiyon bulunamadı | Nil Mobilya" }, {
			name: "robots",
			content: "noindex"
		}] };
		const { collection } = loaderData;
		return { meta: [
			{ title: `Nil Mobilya | ${collection.title} Koleksiyonu` },
			{
				name: "description",
				content: collection.description
			},
			{
				property: "og:title",
				content: `Nil Mobilya | ${collection.title} Koleksiyonu`
			},
			{
				property: "og:description",
				content: collection.description
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
