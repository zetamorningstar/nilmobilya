import { n as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hover-preview-CQuwEoW5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CAPTION_WIDTH = 230;
var CAPTION_GAP = 26;
var DESIRED_ZOOM = 1.22;
function buildState(input, rect, naturalScale) {
	const vw = window.innerWidth;
	const vh = window.innerHeight;
	const zoom = Math.max(1, Math.min(DESIRED_ZOOM, naturalScale));
	const captionLeft = Math.min(rect.right + CAPTION_GAP, vw - CAPTION_WIDTH - 12);
	const connectorLeft = rect.right;
	const connectorWidth = Math.max(0, captionLeft - CAPTION_GAP - rect.right);
	const captionTop = rect.top + Math.min(rect.height * .22, 140);
	return {
		...input,
		left: rect.left,
		top: rect.top,
		width: rect.width,
		height: rect.height,
		zoom,
		captionLeft,
		captionTop: Math.min(captionTop, vh - 160),
		captionWidth: CAPTION_WIDTH,
		connectorLeft,
		connectorWidth,
		connectorTop: Math.min(captionTop, vh - 160) + 18
	};
}
function measureNaturalScale(src, rect) {
	return new Promise((resolve) => {
		const img = new Image();
		const done = (value) => resolve(value);
		img.onload = () => {
			const byWidth = img.naturalWidth / rect.width;
			const byHeight = img.naturalHeight / rect.height;
			done(Math.min(byWidth, byHeight));
		};
		img.onerror = () => done(DESIRED_ZOOM);
		img.src = src;
		setTimeout(() => done(DESIRED_ZOOM), 2500);
	});
}
function useHoverPreview(delay = 1100) {
	const [state, setState] = (0, import_react.useState)(null);
	const [active, setActive] = (0, import_react.useState)(false);
	const timer = (0, import_react.useRef)(null);
	const clear = (0, import_react.useCallback)(() => {
		if (timer.current) {
			clearTimeout(timer.current);
			timer.current = null;
		}
	}, []);
	const open = (0, import_react.useCallback)((input, element) => {
		clear();
		timer.current = setTimeout(() => {
			const rect = element.getBoundingClientRect();
			measureNaturalScale(input.src, rect).then((naturalScale) => {
				setState(buildState(input, rect, naturalScale));
				requestAnimationFrame(() => requestAnimationFrame(() => setActive(true)));
			});
		}, delay);
	}, [clear, delay]);
	const close = (0, import_react.useCallback)(() => {
		clear();
		setActive(false);
		setState(null);
	}, [clear]);
	(0, import_react.useEffect)(() => clear, [clear]);
	return {
		open,
		close,
		overlay: state ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			"aria-hidden": true,
			className: "pointer-events-none fixed inset-0 z-50",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0",
					style: {
						background: "color-mix(in oklab, var(--background) 74%, transparent)",
						opacity: active ? 1 : 0,
						transition: "opacity 320ms linear"
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						position: "absolute",
						left: state.left,
						top: state.top,
						width: state.width,
						height: state.height,
						overflow: "hidden",
						boxShadow: active ? "0 30px 70px oklch(0 0 0 / 50%)" : "none",
						transition: "box-shadow 420ms ease",
						willChange: "contents"
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: state.src,
						alt: state.alt,
						className: "h-full w-full object-cover",
						style: {
							transform: active ? `scale(${state.zoom})` : "scale(1)",
							transition: "transform 420ms cubic-bezier(.22,1,.36,1)",
							willChange: "transform"
						}
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
					position: "absolute",
					left: state.connectorLeft,
					top: state.connectorTop,
					width: active ? state.connectorWidth : 0,
					height: 1,
					background: "var(--color-primary)",
					opacity: active ? .8 : 0,
					transition: "width 340ms cubic-bezier(.22,1,.36,1) 120ms, opacity 240ms linear 120ms"
				} }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						position: "absolute",
						left: state.captionLeft,
						top: state.captionTop,
						width: state.captionWidth,
						opacity: active ? 1 : 0,
						transform: active ? "translate3d(0,0,0)" : "translate3d(-8px,0,0)",
						transition: "opacity 300ms linear 180ms, transform 380ms cubic-bezier(.22,1,.36,1) 180ms"
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-black/90 px-4 py-3 shadow-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-sans text-[11px] font-semibold uppercase tracking-[0.22em] text-primary",
							children: state.title
						})
					}), state.lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-[3px] bg-black/85 px-4 py-2 shadow-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-sans text-[11px] font-light leading-5 tracking-wide",
							style: {
								color: "var(--color-gold-bright)",
								opacity: 1 - index * .15
							},
							children: line
						})
					}, line))]
				})
			]
		}) : null
	};
}
//#endregion
export { useHoverPreview as t };
